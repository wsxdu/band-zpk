/* 音乐遥控 - 歌单页面 (BandMusic 音乐遥控) v2.1 UI
 * 深色风格；仅 FILL_RECT/TEXT/BUTTON；VISIBLE 用 prop.VISIBLE 单独设置
 */
var LOG;
try { LOG = Logger.getLogger("music-list"); }
catch (e) { LOG = { log: function(){}, warn: function(){}, error: function(){} }; }

var C_BG   = 0x000000;
var C_HEADER = 0x1c1c1e;
var C_MAIN = 0xffffff;
var C_SUB  = 0x8e8e93;
var C_TER  = 0x636366;
var C_BTN  = 0x2c2c2e;
var C_BTN_PRESS = 0x3a3a3c;

var PER_PAGE = 5;
var songs = [], total = 0, page = 0, loaded = false, querying = false;
var itemBtns = [], wPageInfo = null, wEmpty = null;

function msg() {
  try { return AppContext.getApp().globalData.messageBuilder; }
  catch (e) { return null; }
}
function setVis(w, show) {
  try { if (w) w.setProperty(hmUI.prop.VISIBLE, show); } catch (e) {}
}
function showList() {
  try {
    var start = page * PER_PAGE, i, idx;
    for (i = 0; i < PER_PAGE; i++) {
      var b = itemBtns[i];
      if (!b) continue;
      idx = start + i;
      if (idx < total) {
        var it = songs[idx];
        var label = (idx + 1) + ". " + (it ? it.title : "");
        if (it && it.artist) label = label + " - " + it.artist;
        b.setProperty(hmUI.prop.TEXT, label);
        setVis(b, true);
      } else {
        setVis(b, false);
      }
    }
    if (wPageInfo) wPageInfo.setProperty(hmUI.prop.TEXT, (page + 1) + " / " + Math.max(1, Math.ceil(total / PER_PAGE)));
  } catch (e) {}
}
function load() {
  if (querying || loaded) return;
  querying = true;
  var mb = msg();
  if (!mb) return;
  mb.request({ method: "PLAYLIST", timeout: 8000 }).then(function (data) {
    querying = false;
    try {
      if (data && data.ok === false) { setVis(wEmpty, true); return; }
      var arr = data && data.list ? data.list : [];
      songs = []; total = 0; var i;
      for (i = 0; i < arr.length; i++) {
        var a = arr[i];
        var o = (typeof a === "string") ? { title: a, artist: "" } : a;
        if (!o || !o.title) continue;
        songs.push({ title: "" + o.title, artist: (o.artist || "") });
        total++;
      }
      if (data && data.listSize !== undefined) total = data.listSize;
      page = 0; loaded = true;
      setVis(wEmpty, false);
      showList();
    } catch (e) {}
  }).catch(function () {
    querying = false;
    setVis(wEmpty, true);
  });
}
function onItem(i) {
  var idx = page * PER_PAGE + i;
  if (idx >= 0 && idx < total) {
    var mb = msg();
    if (mb) mb.request({ method: "PLAYAT", idx: idx, timeout: 8000 });
  }
}
function onItem0(){ onItem(0); }
function onItem1(){ onItem(1); }
function onItem2(){ onItem(2); }
function onItem3(){ onItem(3); }
function onItem4(){ onItem(4); }
function onPrevPage() { if (page > 0) { page--; showList(); } }
function onNextPage() { var maxp = Math.max(0, Math.ceil(total / PER_PAGE) - 1); if (page < maxp) { page++; showList(); } }
function goBack() { try { hmApp.goBack(); } catch (e) {} }

Page({
  state: {},
  onInit: function () { LOG.log("list page onInit"); },
  build: function () {
    try {
      LOG.log("list page build");
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: 192, h: 490, radius: 0, color: C_BG });
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: 192, h: 46, radius: 0, color: C_HEADER });

      hmUI.createWidget(hmUI.widget.BUTTON, { x: 6, y: 7, w: 52, h: 32, radius: 8, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "返回", text_size: 14, color: C_MAIN, click_func: goBack });
      hmUI.createWidget(hmUI.widget.TEXT, { x: 64, y: 8, w: 96, h: 30, color: C_MAIN, text_size: 18, text: "歌单", align_h: hmUI.align.CENTER_H });

      var i, y = 56, fns = [onItem0, onItem1, onItem2, onItem3, onItem4];
      for (i = 0; i < PER_PAGE; i++) {
        var b = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 8, y: y, w: 176, h: 46, radius: 10,
          normal_color: C_BTN, press_color: C_BTN_PRESS,
          text: "", text_size: 14, color: C_MAIN, click_func: fns[i]
        });
        itemBtns.push(b);
        y += 54;
      }

      wPageInfo = hmUI.createWidget(hmUI.widget.TEXT, { x: 66, y: 344, w: 60, h: 32, color: C_SUB, text_size: 15, text: "1 / 1", align_h: hmUI.align.CENTER_H });
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 10, y: 340, w: 50, h: 38, radius: 10, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "上一页", text_size: 13, color: C_MAIN, click_func: onPrevPage });
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 132, y: 340, w: 50, h: 38, radius: 10, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "下一页", text_size: 13, color: C_MAIN, click_func: onNextPage });

      wEmpty = hmUI.createWidget(hmUI.widget.TEXT, { x: 16, y: 180, w: 160, h: 24, color: C_TER, text_size: 14, text: "歌单为空或手机未开启", align_h: hmUI.align.CENTER_H });

      try { hmApp.registerGestureEvent(hmApp.gesture.DOWN, goBack); } catch (e) {}

      load();
    } catch (e) {
      LOG.error("Build Error: " + e);
      try { e && e.stack && e.stack.split(/\n/).forEach(function (l) { LOG.error(l); }); } catch (e2) {}
    }
  },
  onDestroy: function () {
    try { hmApp.unregisterGestureEvent(hmApp.gesture.DOWN, goBack); } catch (e) {}
  }
});