/* 音乐遥控 - 主页面 (BandMusic 音乐遥控) v2.1 UI
 * 遵循文档3.3深色风格；仅 FILL_RECT/TEXT/BUTTON；
 * 关键：Zepp OS 1.0 不可用 setInterval/setTimeout(v2.0黑屏根因)，统一用 timer.createTimer
 */
var LOG;
try { LOG = Logger.getLogger("music-remote"); }
catch (e) { LOG = { log: function(){}, warn: function(){}, error: function(){} }; }

var C_BG      = 0x000000;
var C_HEADER  = 0x1c1c1e;
var C_CARD    = 0x1c1c1e;
var C_MAIN    = 0xffffff;
var C_SUB     = 0x8e8e93;
var C_TER     = 0x636366;
var C_GREEN   = 0x00c853;
var C_ERR     = 0xff3b30;
var C_BTN     = 0x2c2c2e;
var C_BTN_PRESS = 0x3a3a3c;

var state = {
  isPlaying: false, title: "", artist: "",
  position: 0, duration: 0, currentIndex: 0, listSize: 0,
  connected: false, querying: false
};

var wStatusDot = null, wStatusText = null, wTitle = null, wArtist = null;
var wCur = null, wTotal = null, wFill = null, wCount = null, wPlay = null;
var volLevel = 7;
var pollTimer = null, tickTimer = null;

function msg() {
  try { return AppContext.getApp().globalData.messageBuilder; }
  catch (e) { return null; }
}
function fmtTime(ms) {
  if (!ms || ms < 0) return "0:00";
  var s = Math.floor(ms / 1000), m = Math.floor(s / 60), r = s % 60;
  return "" + m + ":" + (r < 10 ? "0" + r : "" + r);
}
function safeSetText(w, t) {
  try { if (w) w.setProperty(hmUI.prop.TEXT, "" + (t || "")); } catch (e) {}
}
function setStatusConnected(ok) {
  state.connected = ok;
  try {
    if (wStatusDot) wStatusDot.setProperty(hmUI.prop.MORE, { color: ok ? C_GREEN : C_ERR });
    if (wStatusText) safeSetText(wStatusText, ok ? "已连接" : "未连接");
  } catch (e) {}
}
function setProgress() {
  try {
    var d = state.duration, p = state.position;
    var ratio = (d > 0) ? (p / d) : 0;
    if (ratio > 1) ratio = 1; if (ratio < 0) ratio = 0;
    var w = Math.floor(140 * ratio);
    if (wFill) wFill.setProperty(hmUI.prop.MORE, { w: w });
    safeSetText(wCur, fmtTime(p));
    safeSetText(wTotal, fmtTime(d));
  } catch (e) {}
}
function setCount() { safeSetText(wCount, "" + state.currentIndex + " / " + state.listSize); }

function applyStatus(data) {
  if (data) {
    if (data.isPlaying !== undefined) state.isPlaying = !!data.isPlaying;
    if (data.title !== undefined) state.title = data.title || "";
    if (data.artist !== undefined) state.artist = data.artist || "";
    if (data.position !== undefined) state.position = data.position || 0;
    if (data.duration !== undefined) state.duration = data.duration || 0;
    if (data.currentIndex !== undefined) state.currentIndex = data.currentIndex || 0;
    if (data.listSize !== undefined) state.listSize = data.listSize || 0;
  }
  safeSetText(wTitle, state.title || "未在播放");
  safeSetText(wArtist, state.artist || "BandMusic");
  safeSetText(wPlay, state.isPlaying ? "暂停" : "播放");
  setProgress(); setCount(); setStatusConnected(true);
}
function doRequest(payload) {
  var mb = msg();
  if (!mb) { setStatusConnected(false); return; }
  if (state.querying) return;
  state.querying = true;
  payload.timeout = 8000;
  mb.request(payload).then(function (data) {
    state.querying = false;
    try {
      if (data && data.ok === false) { setStatusConnected(false); return; }
      applyStatus(data);
    } catch (e) {}
  }).catch(function () {
    state.querying = false;
    setStatusConnected(false);
  });
}
function pollStatus() { doRequest({ method: "STATUS" }); }

function onPrev()     { doRequest({ method: "PREV" }); }
function onNext()     { doRequest({ method: "NEXT" }); }
function onToggle()   { doRequest({ method: "TOGGLE" }); }
function onOpenList() { try { hmApp.gotoPage({ url: "page/band7/list.page" }); } catch (e) {} }
function onVolDown()  { volLevel = volLevel - 1; if (volLevel < 0) volLevel = 0; doRequest({ method: "VOLUME", lv: volLevel }); }
function onVolUp()    { volLevel = volLevel + 1; if (volLevel > 15) volLevel = 15; doRequest({ method: "VOLUME", lv: volLevel }); }

Page({
  state: {},
  onInit: function () { LOG.log("music remote page onInit"); },
  build: function () {
    try {
      LOG.log("music remote page build");
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: 192, h: 490, r: 0, color: C_BG });

      /* 1 顶部状态栏 */
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: 192, h: 46, radius: 0, color: C_HEADER });
      hmUI.createWidget(hmUI.widget.TEXT, { x: 16, y: 11, w: 110, h: 24, color: C_MAIN, text_size: 18, text: "音乐遥控", align_h: hmUI.align.LEFT });
      wStatusDot = hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 132, y: 18, w: 10, h: 10, radius: 0, color: C_ERR });
      wStatusText = hmUI.createWidget(hmUI.widget.TEXT, { x: 144, y: 11, w: 40, h: 24, color: C_SUB, text_size: 16, text: "连接中", align_h: hmUI.align.RIGHT });

      /* 2 歌曲信息卡片 */
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 8, y: 54, w: 176, h: 138, radius: 12, color: C_CARD });
      wTitle = hmUI.createWidget(hmUI.widget.TEXT, { x: 18, y: 64, w: 156, h: 44, color: C_MAIN, text_size: 17, text_style: hmUI.text_style.ONE_LINE, text: "未在播放", align_h: hmUI.align.LEFT });
      wArtist = hmUI.createWidget(hmUI.widget.TEXT, { x: 18, y: 106, w: 156, h: 24, color: C_SUB, text_size: 14, text_style: hmUI.text_style.ONE_LINE, text: "BandMusic", align_h: hmUI.align.LEFT });

      /* 进度条 */
      hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 18, y: 138, w: 156, h: 4, radius: 2, color: C_BTN });
      wFill = hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 18, y: 138, w: 1, h: 4, radius: 2, color: C_GREEN });
      wCur = hmUI.createWidget(hmUI.widget.TEXT, { x: 18, y: 148, w: 62, h: 18, color: C_TER, text_size: 13, text: "0:00", align_h: hmUI.align.LEFT });
      wTotal = hmUI.createWidget(hmUI.widget.TEXT, { x: 112, y: 148, w: 62, h: 18, color: C_TER, text_size: 13, text: "0:00", align_h: hmUI.align.RIGHT });
      wCount = hmUI.createWidget(hmUI.widget.TEXT, { x: 56, y: 170, w: 80, h: 18, color: C_SUB, text_size: 13, text: "0 / 0", align_h: hmUI.align.CENTER_H });

      /* 3 控制按钮 */
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 10, y: 204, w: 52, h: 56, radius: 12, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "上一首", text_size: 14, color: C_MAIN, click_func: onPrev });
      wPlay = hmUI.createWidget(hmUI.widget.BUTTON, { x: 70, y: 204, w: 52, h: 56, radius: 12, normal_color: C_GREEN, press_color: C_BTN_PRESS, text: "播放", text_size: 15, color: 0x002b00, click_func: onToggle });
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 130, y: 204, w: 52, h: 56, radius: 12, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "下一首", text_size: 14, color: C_MAIN, click_func: onNext });

      /* 4 底部操作区 */
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 10, y: 272, w: 172, h: 40, radius: 10, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "查看歌单", text_size: 15, color: C_MAIN, click_func: onOpenList });
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 10, y: 320, w: 84, h: 36, radius: 10, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "音量-", text_size: 14, color: C_MAIN, click_func: onVolDown });
      hmUI.createWidget(hmUI.widget.BUTTON, { x: 98, y: 320, w: 84, h: 36, radius: 10, normal_color: C_BTN, press_color: C_BTN_PRESS, text: "音量+", text_size: 14, color: C_MAIN, click_func: onVolUp });

      /* 5 底部提示 */
      hmUI.createWidget(hmUI.widget.TEXT, { x: 10, y: 372, w: 172, h: 20, color: C_TER, text_size: 12, text: "请确保手机端已开启", align_h: hmUI.align.CENTER_H });

      pollStatus();
      pollTimer = timer.createTimer(0, 5000, pollStatus);
      tickTimer = timer.createTimer(1000, 1000, function () {
        if (state.isPlaying && state.duration > 0) {
          state.position += 1000;
          if (state.position > state.duration) state.position = state.duration;
          setProgress();
        }
      });
    } catch (e) {
      LOG.error("Build Error: " + e);
      try { e && e.stack && e.stack.split(/\n/).forEach(function (l) { LOG.error(l); }); } catch (e2) {}
    }
  },
  onDestroy: function () {
    if (pollTimer) { try { timer.stopTimer(pollTimer); } catch (e) {} pollTimer = null; }
    if (tickTimer) { try { timer.stopTimer(tickTimer); } catch (e) {} tickTimer = null; }
  }
});